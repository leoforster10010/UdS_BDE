
## Copyright

Copyright of all code by Prof. Dr. Jens Dittrich, Saarland University

All code is licensed under the Creative Commons Attribution-NonCommercial 4.0 International License. 

To view a copy of this license, visit
https://creativecommons.org/licenses/by-nc/4.0/legalcode.en
